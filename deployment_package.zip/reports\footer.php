    </main>

<footer class="site-footer">
    <div class="footer-left">
        <span class="footer-brand">ShadowPulse Reports</span> &copy; <span id="year"></span>
    </div>
</footer>
</div>
<div class="bottom-separator"></div>
<script>
document.getElementById('year').textContent = new Date().getFullYear();
</script>
</body>
</html>
