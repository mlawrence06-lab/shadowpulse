<?php
// ranking.php
// Ranking Reports using SyncFusion Grid and Chart

require_once __DIR__ . '/../../api/v1/cors.php';

$pageTitle = "Ranking Reports";
$pageSubtitle = "Top Metrics & Stats";

// Use Main Header/Footer
include __DIR__ . '/../header.php';
?>

<!-- SyncFusion Dependencies (CDN) -->
<link href="https://cdn.syncfusion.com/ej2/24.1.41/tailwind.css" rel="stylesheet">
<script src="https://cdn.syncfusion.com/ej2/24.1.41/dist/ej2.min.js"></script>

<style>
    .report-controls {
        margin-bottom: 20px;
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .report-btn {
        padding: 8px 16px;
        border: 1px solid #ddd;
        background: #f9f9f9;
        cursor: pointer;
        border-radius: 4px;
        transition: all 0.2s;
    }

    .report-btn:hover {
        background: #eee;
    }

    .report-btn.active {
        background: #007bff;
        color: white;
        border-color: #007bff;
    }

    .grid-container {
        margin-bottom: 30px;
        max-width: 85%;
        margin-left: auto;
        margin-right: auto;
    }

    /* Highlight every 3rd row */
    .e-grid .e-row:nth-child(3n) .e-rowcell {
        background-color: #f9f9f9;
        /* You can adjust color as needed, e.g., a light yellow or blue */
    }

    <section class="content"><div class="content-header"><div class="content-title">Ranking Reports</div><div class="content-subtitle">Visualize top performing members by various metrics. </div></div><div class="content-body"><div class="report-controls"><button class="report-btn active" onclick="loadReport('page_views', this)">Most Page Views</button><button class="report-btn" onclick="loadReport('searches', this)">Most Searches</button><button class="report-btn" onclick="loadReport('topic_votes', this)">Most Topic Votes</button><button class="report-btn" onclick="loadReport('post_votes', this)">Most Post Votes</button><button class="report-btn" onclick="loadReport('installs', this)">Recent Installs</button></div>< !-- Grid --><div id="container-grid" class="grid-container"></div></div></section><script>let currentType='page_views';
    let grid;

    // Initialize SyncFusion components
    function initComponents() {

        // Grid
        grid = new ej.grids.Grid({

            dataSource: [],
            allowPaging: true,
            pageSettings: {
                pageSize: 20
            },
            allowSorting: true,
            toolbar: ['Search'], // Add Search
            columns: [{
                field: 'Rank',
                headerText: 'Rank',
                width: 80,
                textAlign: 'Center'
            },
            // Combine ID and Username if requested, or keep separate columns. 
            // User asked: "rank, member id and count. For member id, show the username if they have one."
            // I'll show "Member ID" as the Username if available, or just Member ID.
            // Or better: Column "Member" which shows "Username (ID)" or just "Username".
            // Let's stick to "Member ID" Header but show Username? That's confusing.
            // User: "For member id, show the username if they have one." 
            // This implies the column might be called "Member ID" but displays Username?
            // I will make a column "Member" that shows the display name.
                {
                field: 'Username', headerText: 'Member', width: 200
            }

            ,
            {
            field: 'MemberID', headerText: 'ID', width: 100, visible: false
        }

        , // Hide raw ID if we show Username? Or show both?
        // "For member id, show the username..." - Sounds like ONE column.
        // I will show Username column.

            {
            field: 'Value', headerText: 'Count', width: 120, textAlign: 'Right'
        }

        , // Dynamic Header

            {
            field: 'InstallDate', headerText: 'Install Date', width: 150, format: 'yMd', visible: false
        }

        ]
    });
    grid.appendTo('#container-grid');
    }

    // Load Data
    function loadReport(type, btnElement) {
        currentType=type;

        // Update UI buttons
        if(btnElement) {
            document.querySelectorAll('.report-btn').forEach(b=> b.classList.remove('active'));
            btnElement.classList.add('active');
        }

        // Fetch API
        const apiUrl=`../../api/v1/ranking_reports.php?type=$ {
            type
        }

        `;

        fetch(apiUrl) .then(res=> res.json()) .then(res=> {
                if (res.ok) {
                    updateView(res.data, type);
                }

                else {
                    console.error("API Error:", res.error);
                }
            }) .catch(err=> console.error("Fetch error:", err));
    }

    function updateView(data, type) {
        // Update Grid
        grid.dataSource=data;

        // Dynamic Header for 'Value' column
        let valueHeader="Count";
        if (type==='page_views') valueHeader="Page Views";
        if (type==='searches') valueHeader="Searches";
        if (type==='topic_votes') valueHeader="Topic Votes";
        if (type==='post_votes') valueHeader="Post Votes";
        if (type==='installs') valueHeader="Install Date";

        grid.columns[3].headerText=valueHeader;

        // Visibility toggles
        if (type==='installs') {
            grid.columns[3].visible=false; // Hide 'Value' (Count)
            grid.columns[4].visible=true; // Show 'InstallDate'
        }

        else {
            grid.columns[3].visible=true;
            grid.columns[4].visible=false;
            grid.columns[3].format='N0';
        }

        grid.refreshHeader();
    }

    // Init
    document.addEventListener('DOMContentLoaded', ()=> {
            initComponents();
            loadReport('page_views'); // Default load
        });

    </script><?php include __DIR__ . '/../footer.php'; ?>